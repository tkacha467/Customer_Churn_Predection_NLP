# Vraja Release Artifact — 2.0.0-staging

Created: `2026-10-22T12:29:44Z`

## Start the shared backend

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn Backend.app.main:app --host 127.0.0.1 --port 8000
```

## Product frontends

Build and run each Vite app from its product `frontend/` directory. Both use the shared backend and same-origin `/api` paths by default.

## File checksums

| Path | Bytes | SHA-256 |
|---|---:|---|
| `.dockerignore` | 991 | `fb7fa18601e49634114107664ebc234de4d06a26d3505d8fac7f09473669db66` |
| `.env.example` | 618 | `8a6ceae57877245783474ba44fc16d328760037541e6eff90546da52c50c60ec` |
| `Backend/.gitkeep` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/README.md` | 1378 | `ac83d0967fcbc0fae304db7b5de1952238f220bd9fd156365047663ab333dcfd` |
| `Backend/__init__.py` | 25 | `1e81810dbfc61df3dbd4a756190a5ed6c3121cbf3a9df95c95367baa0fcecb6c` |
| `Backend/app/__init__.py` | 73 | `39a5991fe675bfc6a2fddb9f9fa435d12ca483f50431e49e3ba8faee47ce1023` |
| `Backend/app/api/__init__.py` | 125 | `695e6d69e4a4dbaca94f3dfbd8d54a2dc2c40b9d1309f0778240167dc427a829` |
| `Backend/app/api/document_storage.py` | 9566 | `c87a568250f83a12302085b8fb90bb256aae89025f9a0029cae18780a81e09aa` |
| `Backend/app/api/generator.py` | 3778 | `ac5445cf36840ae76c49b1e50e6f6a07c041303e6fec98a2873f2e99c27159b9` |
| `Backend/app/api/llm_provider.py` | 8608 | `a964a211fed5761afb3cda59376493baac23083500d0bc15a8b07b1bced6cd1b` |
| `Backend/app/api/prompts.py` | 29059 | `00b11c2b6a49c9222ecef3e0d3a1450d3a6c1563b79e2fdb835fba9e810bef25` |
| `Backend/app/api/routes.py` | 52367 | `62dd424df3e7b1faabc08dcefb21e1cda00813a373c6f90d8e21ba2b680805de` |
| `Backend/app/api/service.py` | 12580 | `772076a1c2fb2a498bd66b9af3eda359f322326160e039c5d6dc1829ee35a308` |
| `Backend/app/api/validator.py` | 3622 | `6391d1260b8a217e636860de80cb7b1adb0b0d70b3753de1bfa080b60ba3a8fb` |
| `Backend/app/config/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/config/settings.py` | 1011 | `af2464c0ac50989862f94f4d50d61ce7782f3152ce5021cc6fba29efdfeb98c5` |
| `Backend/app/core/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/core/auth/auth.py` | 13354 | `0c006b6fe67c3275b68a50c338a8793e2c7e0c4353b1b15b163dff763aff51e7` |
| `Backend/app/core/database/migration.py` | 3792 | `bb909f7b15e107dd363dc688ff3ace79fdb93efd778a31c89e416c42eff83e88` |
| `Backend/app/core/database/storage.py` | 45289 | `76f9488bf925b54a03d90edfd06d3ad22b3f23910b3291b76c7cef75b72a112b` |
| `Backend/app/core/entitlements/entitlements.py` | 2188 | `39deb42b518da1e114f7083bc3fb65266c07865797bd29aaad4ac12a3d074612` |
| `Backend/app/core/tenants/business_links.json` | 2982 | `e4a6646a4752f18b60fb91bebc3e77a0f9dc6c79db22a253203448c7a71a7687` |
| `Backend/app/core/tenants/google_reviews.py` | 13032 | `88c95ab1a4b9fc2984cac21fdf71d9989b3c3db746bd5e3c10ae0132ccb7765b` |
| `Backend/app/fusion/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/fusion/engine.py` | 2319 | `7ce88243b7e545b65d69bb66c12ee411fb10812b2458ed6e5deda695be8f9eae` |
| `Backend/app/fusion/explainer.py` | 1176 | `84e50a3207d65d205959f99c62647f676eb0a4c4c98a0f066a5e3c222db9ab5f` |
| `Backend/app/main.py` | 8509 | `34981288e9ee428ca1753195bf3c203c668329008f222ce2b1dca72b78659eaa` |
| `Backend/app/models/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/models/model_loader.py` | 3937 | `da254a3745a6c44210319f908c30d8c2a31e52797df37810c181f09ef6317a51` |
| `Backend/app/models/sarcasm.py` | 849 | `a81c83cbb98b8b2db705b2d1c5a2da069ecf5304e77c4c612b6eb0398b679b6a` |
| `Backend/app/models/sentiment.py` | 1419 | `fc7e984ce707ecda43149ab75dea4ba7e5443e9df13bc1f3485e2f272e7bbd42` |
| `Backend/app/preprocessing/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/preprocessing/text_cleaner.py` | 1895 | `18477ab046e5ce4055fde15fd80e2c1ea8fb3ffc42cbbf4a3d7f4387558fa238` |
| `Backend/app/schemas.py` | 16977 | `e249b43b353b2e5ef3644cd60ccd9b37fd8cf05d620cc5c4996eb40bcebd8124` |
| `Digital_Card/.DS_Store` | 8196 | `4a9ed27a54e316b38fcacfa6c1bd7c671e6b36a1d2643c19c7aa6a21ece224e7` |
| `Digital_Card/README.md` | 1135 | `0f30cb6266d0c97edf060263b0e39b19134e83cdc6045481103b681bb069d768` |
| `Digital_Card/clients/README.md` | 423 | `110dfbd58475e0ef1d080671e195654df126f183dfe27870fd0dca1ffd926279` |
| `Digital_Card/clients/nasta-ghar/brand.json` | 510 | `7cbce271fdc2e5e5edd4c8b8bcc3607bb6f596e4e7ad5e0082d0959d7198715e` |
| `Digital_Card/frontend/.env.example` | 182 | `fd97071b08cf415daedce3469bd1b2ce71398529c0702a2597b6d7b4f6856689` |
| `Digital_Card/frontend/.oxlintrc.json` | 51 | `257efb2596a766451ea16a9090681e7391be76bff5a595277d51789120ce167e` |
| `Digital_Card/frontend/dist/assets/index-BNLS3m7c.js` | 269972 | `ff51d08fa6a3a6e653806b55f1777b87abd74a307ef5660aaf2141e180b9fa8c` |
| `Digital_Card/frontend/dist/assets/index-ClXqF-sz.css` | 104804 | `0d9eb917655a67f56281e603316423a45b5058b8358735780c728d4a3aa93502` |
| `Digital_Card/frontend/dist/favicon.svg` | 9522 | `61bc9a161de58248288e6905425d7180f0624c2865007b97d763fdac12043a66` |
| `Digital_Card/frontend/dist/icons.svg` | 5031 | `b45fa506195cfcdef406ba9f0c77b36ddc1a7c224040926ec70abc2fdea7b93a` |
| `Digital_Card/frontend/dist/index.html` | 1156 | `172bd05a0d9126295b8db3a6f92bb21d7a1305a6eaa158d48c938b01bb0aa55f` |
| `Digital_Card/frontend/dist/restaurant/darshan-host.png` | 315199 | `a69ded9cb9bd88003403460e50f23abfd2435e2c077d2194f6d4fe21f08ccac6` |
| `Digital_Card/frontend/dist/restaurant/scene-phone.webp` | 251728 | `830c53e440ba3571bc4b0b6d091c78861f5744864f6c3a9c6d0be4dbaadd3494` |
| `Digital_Card/frontend/dist/restaurant/scene-wide.webp` | 349362 | `02b8cd404109ec62dd2fef52784aff8413255cf4b93c9710d5adcb3d311f7221` |
| `Digital_Card/frontend/index.html` | 1058 | `fa4833aa83c70467353dd2e0de003c8ae4a833ab2a7d4bcd10524e7f82310cde` |
| `Digital_Card/frontend/package-lock.json` | 55527 | `337852fe6265c6c255216a9d999f96ef27183ea815a3db9a4ed6da1bcdbda718` |
| `Digital_Card/frontend/package.json` | 505 | `f57473ca64416bcf9e41257a7d2ed19df7a855b33cc2512db33bde01bbbc51c4` |
| `Digital_Card/frontend/public/favicon.svg` | 9522 | `61bc9a161de58248288e6905425d7180f0624c2865007b97d763fdac12043a66` |
| `Digital_Card/frontend/public/icons.svg` | 5031 | `b45fa506195cfcdef406ba9f0c77b36ddc1a7c224040926ec70abc2fdea7b93a` |
| `Digital_Card/frontend/public/restaurant/darshan-host.png` | 315199 | `a69ded9cb9bd88003403460e50f23abfd2435e2c077d2194f6d4fe21f08ccac6` |
| `Digital_Card/frontend/public/restaurant/scene-phone.webp` | 251728 | `830c53e440ba3571bc4b0b6d091c78861f5744864f6c3a9c6d0be4dbaadd3494` |
| `Digital_Card/frontend/public/restaurant/scene-wide.webp` | 349362 | `02b8cd404109ec62dd2fef52784aff8413255cf4b93c9710d5adcb3d311f7221` |
| `Digital_Card/frontend/src/App.jsx` | 2339 | `980054586a8a8fff7652f6c966ea9872452a2d0b86eae96f7a4304197dc96c78` |
| `Digital_Card/frontend/src/components/DigitalCard.jsx` | 34265 | `24616bff88257c8ec5c1c9a951e69f0bd1aec202ee34190709bf3a49c4317f0c` |
| `Digital_Card/frontend/src/components/DigitalCardEditor.jsx` | 58292 | `65c944e946236f62538bb408cae94eb07635b5dba905b6ef8d3452230e491bfc` |
| `Digital_Card/frontend/src/index.css` | 148891 | `71838d4efaad33ec9b40f3335a3d6c9f9d270514a3385615ec3e7ab064531039` |
| `Digital_Card/frontend/src/lib/api.js` | 369 | `54c3e3da70d7fd64be2fcfa3d5cf5af9e0a2f05cda35220baaa17af9e117c51c` |
| `Digital_Card/frontend/src/main.jsx` | 229 | `4b4b864dbe45253425d0c925337180ec07e204295179f80f59551216f466f618` |
| `Digital_Card/frontend/vite.config.js` | 524 | `9087007723d1c2ac09799fce3b4072bcd3ade74d78216d39651aab61ae8b11a2` |
| `Dockerfile` | 1997 | `f2da041c0f456875c70375394cba7f785675425afc986f90a2101defa72a102a` |
| `NastaGhar/.DS_Store` | 6148 | `1821b9e8e37efc1ce2d8c3a058162e09a101d0dc95766edcd846c24e4ad81ba0` |
| `NastaGhar/README.md` | 1053 | `03f16307b8e3b90563dffd492ef672008f6595ca2db656314b5bbe76bf3eeef4` |
| `NastaGhar/assets/README.md` | 146 | `a39f2a8f7b1b5839b51a2e845263a0273f8a9d17a789cf2b7189cb5e8a500373` |
| `NastaGhar/frontend/.env.example` | 306 | `635b9c49537faec152bd762a952d90277466f970515925e4bd4d55ebd07abbcc` |
| `NastaGhar/frontend/.gitignore` | 253 | `fe718e7babb14f3cbad2d97f08889b9ce5215ed3fe0e43b2b8cfbfb3b9b844e8` |
| `NastaGhar/frontend/.oxlintrc.json` | 51 | `257efb2596a766451ea16a9090681e7391be76bff5a595277d51789120ce167e` |
| `NastaGhar/frontend/dist/assets/index-CGmaJGCK.css` | 82381 | `74a4e176f6596b5d9ef978385a56fcfbac5ad3f76dd89b305f1fda13373fcd02` |
| `NastaGhar/frontend/dist/assets/index-Dltg3kiI.js` | 332290 | `d8dad993bb3c611ac2bdf9b53fda296aa28182755c50224bbf83a77d568833fd` |
| `NastaGhar/frontend/dist/favicon.svg` | 9522 | `61bc9a161de58248288e6905425d7180f0624c2865007b97d763fdac12043a66` |
| `NastaGhar/frontend/dist/icons.svg` | 5031 | `b45fa506195cfcdef406ba9f0c77b36ddc1a7c224040926ec70abc2fdea7b93a` |
| `NastaGhar/frontend/dist/index.html` | 1156 | `93ed33c41690ea71c0b7f384dd1dfb60763f3429fdd2aa7f80023487d607be4d` |
| `NastaGhar/frontend/dist/restaurant/darshan-host.png` | 315199 | `a69ded9cb9bd88003403460e50f23abfd2435e2c077d2194f6d4fe21f08ccac6` |
| `NastaGhar/frontend/dist/restaurant/scene-phone.webp` | 251728 | `830c53e440ba3571bc4b0b6d091c78861f5744864f6c3a9c6d0be4dbaadd3494` |
| `NastaGhar/frontend/dist/restaurant/scene-wide.webp` | 349362 | `02b8cd404109ec62dd2fef52784aff8413255cf4b93c9710d5adcb3d311f7221` |
| `NastaGhar/frontend/index.html` | 1058 | `fa4833aa83c70467353dd2e0de003c8ae4a833ab2a7d4bcd10524e7f82310cde` |
| `NastaGhar/frontend/package-lock.json` | 55503 | `21b79dcc96ce9e2d555bae6e834bd42db4ce37c9b6bdf2471b648e3d6df0b1f0` |
| `NastaGhar/frontend/package.json` | 493 | `c57ade6addfeb10b90e3a1ce6491af5a6cf1ac2b50cfbf2473a9738352349b90` |
| `NastaGhar/frontend/public/favicon.svg` | 9522 | `61bc9a161de58248288e6905425d7180f0624c2865007b97d763fdac12043a66` |
| `NastaGhar/frontend/public/icons.svg` | 5031 | `b45fa506195cfcdef406ba9f0c77b36ddc1a7c224040926ec70abc2fdea7b93a` |
| `NastaGhar/frontend/public/restaurant/darshan-host.png` | 315199 | `a69ded9cb9bd88003403460e50f23abfd2435e2c077d2194f6d4fe21f08ccac6` |
| `NastaGhar/frontend/public/restaurant/scene-phone.webp` | 251728 | `830c53e440ba3571bc4b0b6d091c78861f5744864f6c3a9c6d0be4dbaadd3494` |
| `NastaGhar/frontend/public/restaurant/scene-wide.webp` | 349362 | `02b8cd404109ec62dd2fef52784aff8413255cf4b93c9710d5adcb3d311f7221` |
| `NastaGhar/frontend/src/App.jsx` | 6314 | `b3852576361b4ed2cd4385c87d2f54fefc78b04b33131b1b4867f6cd69c1429b` |
| `NastaGhar/frontend/src/components/CustomerReview.jsx` | 56809 | `41db5158f8a8078b4a0463f465ac54eeaff40c930b55a6498e817c2c43470170` |
| `NastaGhar/frontend/src/components/NastaGharRestaurantScene.jsx` | 30485 | `1d27be4b1794310b062455beb7cb18ff79023040bba61e2e8182697785dbad75` |
| `NastaGhar/frontend/src/components/OwnerPortal.jsx` | 38241 | `c0f7e9199a6e0e0519eeeeef791f38ac0527f2c2a45df9848f557feebd2ba468` |
| `NastaGhar/frontend/src/components/RestaurantWorld.css` | 15871 | `33b19b9a33101b1610ad7387345a452c476d194767d8659e8102285d47b4d2c0` |
| `NastaGhar/frontend/src/components/RestaurantWorld.jsx` | 7414 | `c0d2d58351f7d78939c4545693af8eff129f7042c4c38e3347808a767888859a` |
| `NastaGhar/frontend/src/components/VrajaAdmin.jsx` | 44524 | `5ae34cabebd272048bac0b6d807daa421005a9de3fc2e2ecb181dfd05f1d9f17` |
| `NastaGhar/frontend/src/index.css` | 101622 | `d27217263a51aa67226735239c9972b269a5e304557e6a8b036cd84fa8c2a61a` |
| `NastaGhar/frontend/src/lib/api.js` | 345 | `ac2750903bd6a79939d6e30d3fe7a9f5943c8f567a07a1d6f6367804ece72832` |
| `NastaGhar/frontend/src/main.jsx` | 229 | `4b4b864dbe45253425d0c925337180ec07e204295179f80f59551216f466f618` |
| `NastaGhar/frontend/vite.config.js` | 492 | `13312dfcdcedaaf4992c237cf63e0219153a3efe0d1bd2d9f8c9c0dea0f07158` |
| `README.md` | 3597 | `5d57e1a1e36c09ff3073f4be6a6c5b9b406e5667f079d684081ab5cbf9ed27e1` |
| `pyproject.toml` | 552 | `acd4ac16323cbaccce79fbcd4f832ced74e37a137eddbb1b4e4a16982bdb2ee3` |
| `requirements.txt` | 205 | `164f868af305151913263ab4bb5bc44899b0f9375a71d7624c17a3da5e907a30` |
| `scripts/backup_restore.py` | 12484 | `df2dd0eb62be8a3fcacfbe26144216d72e23cd042d029ef9c4e8d73debac5319` |
| `scripts/create_tenant_owner.py` | 6125 | `f38efc27d13829fb727cdd8ed67994c766a990b07c87d2c1892ea5af6a3715bb` |
| `staging.env.example` | 1448 | `b42fc78f518027a2b6878ca17f12156324fd239340206540a7197795a437d001` |
