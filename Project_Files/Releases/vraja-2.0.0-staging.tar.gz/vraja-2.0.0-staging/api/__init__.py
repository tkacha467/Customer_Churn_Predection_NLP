"""
Backward-compatibility shim package for Vraja / ChurnLens.
Canonical code lives in Backend/app.
This shim ensures tests, legacy scripts, and tools continue to function seamlessly.
"""

import sys
from pathlib import Path

_repo_root = Path(__file__).resolve().parent.parent
_backend_path = _repo_root / "Backend"

for _p in (str(_repo_root), str(_backend_path)):
    if _p not in sys.path:
        sys.path.insert(0, _p)
