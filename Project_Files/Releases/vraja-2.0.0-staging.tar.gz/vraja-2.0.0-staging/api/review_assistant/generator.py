"""
Backward-compatibility shim for review generator.
Canonical implementation: app.api.generator.
"""
from app.api.generator import *  # noqa: F401, F403
