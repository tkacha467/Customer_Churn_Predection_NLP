"""
Backward-compatibility shim for ReviewStore database storage.
Canonical implementation: app.core.database.storage.
"""
from app.core.database.storage import *  # noqa: F401, F403
from app.core.database.storage import ReviewStore
