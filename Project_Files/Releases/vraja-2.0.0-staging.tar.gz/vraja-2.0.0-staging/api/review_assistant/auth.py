"""
Backward-compatibility shim for authentication and tenant authorization.
Canonical implementation: app.core.auth.auth.
"""
from app.core.auth.auth import *  # noqa: F401, F403
from app.core.auth.auth import (
    _stores,
    _login_attempts,
    _login_lock,
    _sign,
)
