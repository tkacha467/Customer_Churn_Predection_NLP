"""
Backward-compatibility shim for Digital Business Card document storage.
Canonical implementation: app.api.document_storage.
"""
from app.api.document_storage import *  # noqa: F401, F403
from app.api.document_storage import (
    _document_services,
)
