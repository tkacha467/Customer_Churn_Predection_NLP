"""
Backward-compatibility shim for review LLM provider.
Canonical implementation: app.api.llm_provider.
"""
from app.api.llm_provider import *  # noqa: F401, F403
