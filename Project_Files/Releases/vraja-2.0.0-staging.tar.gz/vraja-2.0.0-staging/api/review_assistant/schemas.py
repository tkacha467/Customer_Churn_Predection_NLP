"""
Backward-compatibility shim for API schemas.
Canonical implementation: Backend/app/schemas.py.
"""
from Backend.app.schemas import *  # noqa: F401, F403
