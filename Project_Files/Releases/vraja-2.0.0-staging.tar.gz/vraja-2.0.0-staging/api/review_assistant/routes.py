"""
Backward-compatibility shim for Review Assistant and Digital Card API routes.
Canonical implementation: app.api.routes.
"""
from app.api.routes import *  # noqa: F401, F403
