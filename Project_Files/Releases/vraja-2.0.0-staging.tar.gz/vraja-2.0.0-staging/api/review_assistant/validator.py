"""
Backward-compatibility shim for review validator.
Canonical implementation: app.api.validator.
"""
from app.api.validator import *  # noqa: F401, F403
