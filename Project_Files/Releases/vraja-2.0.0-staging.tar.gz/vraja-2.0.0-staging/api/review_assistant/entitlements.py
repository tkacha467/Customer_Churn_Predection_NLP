"""
Backward-compatibility shim for tenant product entitlements.
Canonical implementation: app.core.entitlements.entitlements.
"""
from app.core.entitlements.entitlements import *  # noqa: F401, F403
