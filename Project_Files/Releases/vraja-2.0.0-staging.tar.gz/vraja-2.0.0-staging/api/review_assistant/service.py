"""
Backward-compatibility shim for ReviewService.
Canonical implementation: app.api.service.
"""
from app.api.service import *  # noqa: F401, F403
