"""
Backward-compatibility shim for Google Review Manager and tenant configurations.
Canonical implementation: app.core.tenants.google_reviews.
"""
from app.core.tenants.google_reviews import *  # noqa: F401, F403
