"""
Backward-compatibility shim for database migration.
Canonical implementation: app.core.database.migration.
"""
from app.core.database.migration import *  # noqa: F401, F403
from app.core.database.migration import migrate_database
