"""
Backward-compatibility shim for review prompts.
Canonical implementation: app.api.prompts.
"""
from app.api.prompts import *  # noqa: F401, F403
