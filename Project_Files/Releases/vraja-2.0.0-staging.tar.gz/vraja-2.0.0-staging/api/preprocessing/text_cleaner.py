"""
Backward-compatibility shim for text cleaner.
Canonical implementation: app.preprocessing.text_cleaner.
"""
from app.preprocessing.text_cleaner import *  # noqa: F401, F403
