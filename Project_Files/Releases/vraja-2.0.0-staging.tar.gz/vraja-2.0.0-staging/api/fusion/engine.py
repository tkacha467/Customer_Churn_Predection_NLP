"""
Backward-compatibility shim for fusion engine.
Canonical implementation: app.fusion.engine.
"""
from app.fusion.engine import *  # noqa: F401, F403
