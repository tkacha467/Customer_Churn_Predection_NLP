"""
Backward-compatibility shim for explainer.
Canonical implementation: app.fusion.explainer.
"""
from app.fusion.explainer import *  # noqa: F401, F403
