"""
Backward-compatibility shim for sarcasm model.
Canonical implementation: app.models.sarcasm.
"""
from app.models.sarcasm import *  # noqa: F401, F403
