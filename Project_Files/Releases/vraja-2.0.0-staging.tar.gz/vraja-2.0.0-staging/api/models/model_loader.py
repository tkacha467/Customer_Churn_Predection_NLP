"""
Backward-compatibility shim for model loader.
Canonical implementation: app.models.model_loader.
"""
from app.models.model_loader import *  # noqa: F401, F403
