"""
Backward-compatibility shim for sentiment model.
Canonical implementation: app.models.sentiment.
"""
from app.models.sentiment import *  # noqa: F401, F403
