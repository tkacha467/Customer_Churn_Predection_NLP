"""
Backward-compatibility entrypoint for Vraja / ChurnLens API.
Canonical implementation is located in Backend/app/main.py.
"""
import sys
from pathlib import Path

_repo_root = Path(__file__).resolve().parent.parent
_backend_path = _repo_root / "Backend"

for _p in (str(_repo_root), str(_backend_path)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from app.main import *  # noqa: F401, F403
from app.main import app

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("Backend.app.main:app", host="127.0.0.1", port=8000, reload=True)
