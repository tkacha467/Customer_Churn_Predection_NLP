"""
Backward-compatibility shim for application settings.
Canonical implementation: app.config.settings.
"""
from app.config.settings import *  # noqa: F401, F403
