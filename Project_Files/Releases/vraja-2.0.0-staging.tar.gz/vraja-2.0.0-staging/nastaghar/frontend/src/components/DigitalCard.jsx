import { useState, useEffect } from 'react';
import { apiFetch } from '../lib/api';

/**
 * Format bytes to readable string (e.g. 1.2 MB, 450 KB).
 */
function formatBytes(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

/**
 * Format document type identifier into human-readable label.
 */
function formatDocType(type) {
  const map = {
    food_menu: 'Food Menu',
    drinks_menu: 'Drinks Menu',
    dessert_menu: 'Dessert Menu',
    brochure: 'Brochure',
    catalogue: 'Catalogue',
    other: 'Document',
  };
  return map[type] || 'Document';
}

export default function DigitalCard({
  businessId = 'default_business',
  isPreview = false,
  previewData = null,
  onSwitchToEditor = null,
}) {
  const [cardData, setCardData] = useState(previewData);
  const [isLoading, setIsLoading] = useState(!previewData);
  const [notFound, setNotFound] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [copiedNotification, setCopiedNotification] = useState(false);

  useEffect(() => {
    if (previewData) {
      setCardData(previewData);
      setIsLoading(false);
      return;
    }

    let active = true;
    setIsLoading(true);
    setNotFound(false);
    setErrorMessage('');

    // If preview mode is requested without pre-supplied data, fetch from authenticated profile draft
    const endpoint = isPreview
      ? `/api/businesses/${encodeURIComponent(businessId)}/profile`
      : `/api/businesses/${encodeURIComponent(businessId)}/card`;

    apiFetch(endpoint)
      .then(async (res) => {
        if (!active) return;
        if (res.ok) {
          const data = await res.json();
          // If fetched from /profile in preview mode, also fetch published documents and tenant branding
          if (isPreview) {
            try {
              const [docsRes, tenantRes] = await Promise.all([
                apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/documents`),
                apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/review-link`),
              ]);
              const docs = docsRes.ok ? await docsRes.json() : [];
              const tenant = tenantRes.ok ? await tenantRes.json() : {};
              data.business_name = tenant.business_name || businessId;
              data.category = tenant.category || '';
              data.description = tenant.description || '';
              data.primary_accent = tenant.primary_accent || '#f97316';
              data.documents = docs.map((d) => ({
                id: d.id,
                document_type: d.document_type,
                display_name: d.display_name,
                file_size_bytes: d.file_size_bytes,
                download_url: d.download_url || `/api/businesses/${encodeURIComponent(businessId)}/documents/${d.id}/file`,
                is_published: d.is_published,
              }));
            } catch {
              // Gracefully handle partial enrichment in preview mode
            }
          }
          setCardData(data);
        } else if (res.status === 404 || res.status === 403) {
          setNotFound(true);
        } else {
          const err = await res.json().catch(() => ({}));
          setErrorMessage(err.detail || 'Could not load business card.');
        }
      })
      .catch(() => {
        if (active) setErrorMessage('Network connection error. Please refresh.');
      })
      .finally(() => {
        if (active) setIsLoading(false);
      });

    return () => { active = false; };
  }, [businessId, isPreview, previewData]);

  const handleShare = async () => {
    const cardUrl = `${window.location.origin}/b/${encodeURIComponent(businessId)}/card`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: cardData?.business_name || 'Digital Business Card',
          text: cardData?.tagline || `Check out ${cardData?.business_name || 'our business card'}!`,
          url: cardUrl,
        });
        return;
      } catch (err) {
        if (err.name !== 'AbortError') {
          // Fall through to clipboard copy
        } else {
          return;
        }
      }
    }
    try {
      await navigator.clipboard.writeText(cardUrl);
      setCopiedNotification(true);
      setTimeout(() => setCopiedNotification(false), 3000);
    } catch {
      // Fallback
    }
  };

  const handleReviewClick = () => {
    const reviewPath = `/b/${encodeURIComponent(businessId)}/review`;
    window.location.href = reviewPath;
  };

  // ─── LOADING STATE ──────────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="card-outer-wrap">
        <div className="card-stage">
          <div className="card-skeleton">
            <div className="skeleton-cover" />
            <div className="skeleton-avatar" />
            <div className="skeleton-line title" />
            <div className="skeleton-line subtitle" />
            <div className="skeleton-grid" />
          </div>
        </div>
      </div>
    );
  }

  // ─── NOT FOUND / UNPUBLISHED STATE ──────────────────────────────────────────
  if (notFound || !cardData) {
    return (
      <div className="card-outer-wrap">
        <div className="card-stage">
          <div className="card-empty-panel">
            <div className="card-empty-icon">🪪</div>
            <h1 className="card-empty-title">Business Card Not Available</h1>
            <p className="card-empty-desc">
              The digital business card for <strong>{businessId}</strong> is either unpublished,
              does not exist, or the business has not yet activated digital card features.
            </p>
            {onSwitchToEditor && (
              <button
                type="button"
                className="card-empty-btn"
                onClick={onSwitchToEditor}
              >
                ✏️ Open Owner Editor
              </button>
            )}
            <div className="card-empty-footer">
              <span>Vraja Hospitality Platform</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (errorMessage) {
    return (
      <div className="card-outer-wrap">
        <div className="card-stage">
          <div className="card-empty-panel">
            <div className="card-empty-icon">⚠️</div>
            <h2 className="card-empty-title">Could Not Load Card</h2>
            <p className="card-empty-desc">{errorMessage}</p>
            <button
              type="button"
              className="card-empty-btn"
              onClick={() => window.location.reload()}
            >
              🔄 Refresh Page
            </button>
          </div>
        </div>
      </div>
    );
  }

  const accentColor = cardData.primary_accent || '#f97316';
  const hasPhone = Boolean(cardData.phone_number && cardData.phone_number.trim());
  const hasWebsite = Boolean(cardData.website_url && cardData.website_url.trim());
  const hasAddress = Boolean(cardData.address && cardData.address.trim());
  const hasMapUrl = Boolean(cardData.map_url && cardData.map_url.trim());
  const hasWhatsApp = Boolean(cardData.whatsapp_url && cardData.whatsapp_url.trim());
  const hasInstagram = Boolean(cardData.instagram_url && cardData.instagram_url.trim());
  const hasFacebook = Boolean(cardData.facebook_url && cardData.facebook_url.trim());
  const hasYouTube = Boolean(cardData.youtube_url && cardData.youtube_url.trim());
  const customLinks = Array.isArray(cardData.custom_links) ? cardData.custom_links : [];
  const documents = Array.isArray(cardData.documents) ? cardData.documents : [];

  // Filter published documents (unless in owner preview mode where drafts are clearly tagged)
  const visibleDocs = isPreview ? documents : documents.filter((d) => d.is_published !== false);

  const cleanWhatsAppUrl = () => {
    if (!hasWhatsApp) return '';
    const raw = cardData.whatsapp_url.trim();
    if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
    const digits = raw.replace(/[^\d+]/g, '');
    return `https://wa.me/${digits.replace(/^\+/, '')}`;
  };

  return (
    <div className="card-outer-wrap">
      {isPreview && (
        <div className="card-preview-banner">
          <div className="preview-badge">👁️ Owner Preview Mode</div>
          <span className="preview-note">This draft preview reflects your current saved settings.</span>
          {onSwitchToEditor && (
            <button
              type="button"
              className="preview-editor-btn"
              onClick={onSwitchToEditor}
            >
              ✏️ Back to Editor
            </button>
          )}
        </div>
      )}

      {copiedNotification && (
        <div className="card-toast" role="status" aria-live="polite">
          ✅ Card link copied to clipboard!
        </div>
      )}

      <main className="card-stage" style={{ '--card-accent': accentColor }}>
        {/* Cover Section */}
        <div
          className="card-cover-wrapper"
          style={
            cardData.cover_image_path
              ? { backgroundImage: `url(${cardData.cover_image_path})`, backgroundSize: 'cover' }
              : { background: `linear-gradient(135deg, ${accentColor}cc 0%, #1e293b 100%)` }
          }
        >
          <div className="card-cover-overlay" />
          <button
            type="button"
            className="card-share-floating-btn"
            onClick={handleShare}
            aria-label="Share this business card"
            title="Share or copy card link"
          >
            ↗
          </button>
        </div>

        {/* Identity Block */}
        <div className="card-identity-block">
          <div className="card-avatar-container">
            {cardData.logo_path ? (
              <img
                src={cardData.logo_path}
                alt={`${cardData.business_name} logo`}
                className="card-avatar-img"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.nextSibling.style.display = 'flex';
                }}
              />
            ) : null}
            <div
              className="card-avatar-fallback"
              style={{ display: cardData.logo_path ? 'none' : 'flex' }}
            >
              {cardData.business_name ? cardData.business_name.charAt(0).toUpperCase() : '🍳'}
            </div>
          </div>

          <h1 className="card-business-name">{cardData.business_name}</h1>
          {cardData.category && (
            <span className="card-category-badge">{cardData.category}</span>
          )}
          {cardData.tagline && (
            <p className="card-tagline">{cardData.tagline}</p>
          )}
        </div>

        {/* Quick Action Ribbon */}
        {(hasPhone || hasWhatsApp || hasMapUrl || hasWebsite) && (
          <div className="card-quick-actions" role="region" aria-label="Quick contact actions">
            {hasPhone && (
              <a
                href={`tel:${cardData.phone_number.trim()}`}
                className="quick-action-item"
                aria-label={`Call ${cardData.business_name}`}
              >
                <div className="quick-action-circle">📞</div>
                <span className="quick-action-label">Call</span>
              </a>
            )}

            {hasWhatsApp && (
              <a
                href={cleanWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="quick-action-item"
                aria-label="Chat on WhatsApp"
              >
                <div className="quick-action-circle whatsapp">💬</div>
                <span className="quick-action-label">WhatsApp</span>
              </a>
            )}

            {hasMapUrl && (
              <a
                href={cardData.map_url}
                target="_blank"
                rel="noopener noreferrer"
                className="quick-action-item"
                aria-label="Get directions in Google Maps"
              >
                <div className="quick-action-circle maps">📍</div>
                <span className="quick-action-label">Directions</span>
              </a>
            )}

            {hasWebsite && (
              <a
                href={cardData.website_url}
                target="_blank"
                rel="noopener noreferrer"
                className="quick-action-item"
                aria-label="Visit website"
              >
                <div className="quick-action-circle web">🌐</div>
                <span className="quick-action-label">Website</span>
              </a>
            )}
          </div>
        )}

        {/* Location & Contact Details */}
        {(hasAddress || hasPhone || hasWebsite) && (
          <section className="card-content-section" aria-label="Business details">
            <h2 className="section-label">Contact & Location</h2>
            <div className="card-detail-card">
              {hasAddress && (
                <div className="detail-row">
                  <span className="detail-icon" aria-hidden="true">📍</span>
                  <div className="detail-text">
                    <span className="detail-title">Address</span>
                    <span className="detail-value">{cardData.address}</span>
                    {hasMapUrl && (
                      <a
                        href={cardData.map_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="detail-link-btn"
                      >
                        Open in Maps →
                      </a>
                    )}
                  </div>
                </div>
              )}

              {hasPhone && (
                <div className="detail-row">
                  <span className="detail-icon" aria-hidden="true">📞</span>
                  <div className="detail-text">
                    <span className="detail-title">Phone</span>
                    <a href={`tel:${cardData.phone_number.trim()}`} className="detail-value link">
                      {cardData.phone_number}
                    </a>
                  </div>
                </div>
              )}

              {hasWebsite && (
                <div className="detail-row">
                  <span className="detail-icon" aria-hidden="true">🌐</span>
                  <div className="detail-text">
                    <span className="detail-title">Website</span>
                    <a
                      href={cardData.website_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="detail-value link"
                    >
                      {cardData.website_url.replace(/^https?:\/\//, '')}
                    </a>
                  </div>
                </div>
              )}
            </div>
          </section>
        )}

        {/* PDF Documents Section (Menus, Brochures, Catalogues) */}
        {visibleDocs.length > 0 && (
          <section className="card-content-section" aria-label="Menus and PDF documents">
            <h2 className="section-label">Menus & Catalogues</h2>
            <div className="card-docs-grid">
              {visibleDocs.map((doc) => (
                <a
                  key={doc.id}
                  href={doc.download_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="card-doc-tile"
                  aria-label={`View ${doc.display_name} PDF`}
                >
                  <div className="doc-tile-left">
                    <div className="doc-pdf-icon" aria-hidden="true">📄</div>
                    <div className="doc-meta-block">
                      <div className="doc-type-pill">{formatDocType(doc.document_type)}</div>
                      <div className="doc-title-text">{doc.display_name}</div>
                      <div className="doc-sub-text">
                        <span>PDF</span>
                        <span>•</span>
                        <span>{formatBytes(doc.file_size_bytes)}</span>
                        {isPreview && doc.is_published === false && (
                          <span className="doc-draft-tag">Draft</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="doc-arrow-btn" aria-hidden="true">
                    📥
                  </div>
                </a>
              ))}
            </div>
          </section>
        )}

        {/* Social Links Ribbon */}
        {(hasInstagram || hasFacebook || hasYouTube) && (
          <section className="card-content-section" aria-label="Social media profiles">
            <h2 className="section-label">Connect With Us</h2>
            <div className="card-social-grid">
              {hasInstagram && (
                <a
                  href={cardData.instagram_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="card-social-btn instagram"
                  aria-label="Instagram profile"
                >
                  <span className="social-icon">📸</span>
                  <span>Instagram</span>
                </a>
              )}
              {hasFacebook && (
                <a
                  href={cardData.facebook_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="card-social-btn facebook"
                  aria-label="Facebook page"
                >
                  <span className="social-icon">👥</span>
                  <span>Facebook</span>
                </a>
              )}
              {hasYouTube && (
                <a
                  href={cardData.youtube_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="card-social-btn youtube"
                  aria-label="YouTube channel"
                >
                  <span className="social-icon">▶️</span>
                  <span>YouTube</span>
                </a>
              )}
            </div>
          </section>
        )}

        {/* Custom Links (Ordering, Delivery, Booking) */}
        {customLinks.length > 0 && (
          <section className="card-content-section" aria-label="Online links">
            <h2 className="section-label">Online Ordering & Links</h2>
            <div className="card-custom-links-list">
              {customLinks.map((link, idx) => (
                <a
                  key={idx}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="card-custom-link-btn"
                >
                  <span className="link-bullet">🔗</span>
                  <span className="link-title-text">{link.title}</span>
                  <span className="link-arrow" aria-hidden="true">↗</span>
                </a>
              ))}
            </div>
          </section>
        )}

        {/* Review on Google Button (Only if allowed by profile AND tenant entitlement) */}
        {cardData.show_review_button && (
          <div className="card-review-action-box">
            <button
              type="button"
              className="card-google-review-btn"
              onClick={handleReviewClick}
              aria-label="Leave a review on Google"
            >
              <span className="review-btn-icon" aria-hidden="true">⭐</span>
              <span className="review-btn-text">Rate & Review Us on Google</span>
            </button>
            <span className="review-sub-caption">Share your experience with our team</span>
          </div>
        )}

        {/* Share Button Block */}
        <div className="card-share-action-box">
          <button
            type="button"
            className="card-secondary-share-btn"
            onClick={handleShare}
          >
            <span>🔗</span>
            <span>Share This Business Card</span>
          </button>
        </div>

        {/* Public Card Footer */}
        <footer className="card-public-footer">
          <span>Digital Business Card • Powered by Vraja</span>
        </footer>
      </main>
    </div>
  );
}
