import { useState, useEffect, useRef, useCallback } from 'react';
import QRCode from 'qrcode';
import { apiFetch } from '../lib/api';
import DigitalCard from './DigitalCard';

const DOCUMENT_CATEGORIES = [
  { id: 'food_menu', label: 'Food Menu', icon: '🍽️' },
  { id: 'drinks_menu', label: 'Drinks & Bar Menu', icon: '🍷' },
  { id: 'dessert_menu', label: 'Dessert Menu', icon: '🍰' },
  { id: 'brochure', label: 'Brochure / Flyer', icon: '📄' },
  { id: 'catalogue', label: 'Product Catalogue', icon: '📖' },
  { id: 'other', label: 'Other PDF Document', icon: '📎' },
];

function formatBytes(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export default function DigitalCardEditor({
  businessId = 'default_business',
  onPreviewCard = null,
  onBackToReviews = null,
}) {
  // Session & Auth state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isCheckingSession, setIsCheckingSession] = useState(true);
  const [ownerEmail, setOwnerEmail] = useState('');
  const [ownerPassword, setOwnerPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [isSigningIn, setIsSigningIn] = useState(false);

  // Tenant & Entitlement info
  const [tenantName, setTenantName] = useState(businessId);
  const [hasCardEntitlement, setHasCardEntitlement] = useState(true);
  const [entitlements, setEntitlements] = useState(['digital_card']);

  // Editor Section Tabs: 'details' | 'contact' | 'social' | 'documents' | 'publish'
  const [activeSection, setActiveSection] = useState('details');

  // Form State
  const [tagline, setTagline] = useState('');
  const [logoPath, setLogoPath] = useState('');
  const [coverImagePath, setCoverImagePath] = useState('');
  const [showReviewButton, setShowReviewButton] = useState(true);
  const [isPublished, setIsPublished] = useState(false);

  const [phoneNumber, setPhoneNumber] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [address, setAddress] = useState('');
  const [mapUrl, setMapUrl] = useState('');

  const [whatsappUrl, setWhatsappUrl] = useState('');
  const [instagramUrl, setInstagramUrl] = useState('');
  const [facebookUrl, setFacebookUrl] = useState('');
  const [youtubeUrl, setYouTubeUrl] = useState('');
  const [customLinks, setCustomLinks] = useState([]);
  const [newLinkTitle, setNewLinkTitle] = useState('');
  const [newLinkUrl, setNewLinkUrl] = useState('');

  // Documents State
  const [documents, setDocuments] = useState([]);
  const [isLoadingDocs, setIsLoadingDocs] = useState(false);
  const [uploadFile, setUploadFile] = useState(null);
  const [uploadCategory, setUploadCategory] = useState('food_menu');
  const [uploadDisplayName, setUploadDisplayName] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const fileInputRef = useRef(null);

  // Document Rename Modal / Edit State
  const [editingDocId, setEditingDocId] = useState(null);
  const [editDocName, setEditDocName] = useState('');
  const [editDocCategory, setEditDocCategory] = useState('food_menu');

  // Saving & Feedback
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');
  const [saveErrorMsg, setSaveErrorMsg] = useState('');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Live Preview Modal
  const [showLivePreview, setShowLivePreview] = useState(false);

  // Card QR code state
  const [cardQrDataUrl, setCardQrDataUrl] = useState('');
  const [cardCopiedToast, setCardCopiedToast] = useState(false);

  // ─── 1. CHECK SESSION ───────────────────────────────────────────────────────
  useEffect(() => {
    let active = true;
    setIsCheckingSession(true);
    apiFetch('/api/auth/session')
      .then(async (res) => {
        if (!active) return;
        if (res.ok) {
          setIsAuthenticated(true);
        } else {
          setIsAuthenticated(false);
        }
      })
      .catch(() => { if (active) setIsAuthenticated(false); })
      .finally(() => { if (active) setIsCheckingSession(false); });

    return () => { active = false; };
  }, []);

  const loadDocuments = useCallback(() => {
    setIsLoadingDocs(true);
    apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/documents`)
      .then(async (res) => {
        if (res.ok) {
          const docs = await res.json();
          setDocuments(docs);
        }
      })
      .catch(() => {})
      .finally(() => setIsLoadingDocs(false));
  }, [businessId]);

  // ─── 2. LOAD PROFILE & TENANT DATA ──────────────────────────────────────────
  useEffect(() => {
    if (!isAuthenticated) return;
    let active = true;

    // Fetch tenant entitlements & business config
    apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/review-link`)
      .then(async (res) => {
        if (!active) return;
        if (res.ok) {
          const t = await res.json();
          setTenantName(t.business_name || businessId);
          const ent = Array.isArray(t.entitlements) ? t.entitlements : ['digital_card'];
          setEntitlements(ent);
          setHasCardEntitlement(ent.includes('digital_card'));
        }
      })
      .catch(() => {});

    // Fetch profile
    apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/profile`)
      .then(async (res) => {
        if (!active) return;
        if (res.ok) {
          const p = await res.json();
          setTagline(p.tagline || '');
          setLogoPath(p.logo_path || '');
          setCoverImagePath(p.cover_image_path || '');
          setShowReviewButton(p.show_review_button !== false);
          setIsPublished(Boolean(p.is_published));
          setPhoneNumber(p.phone_number || '');
          setWebsiteUrl(p.website_url || '');
          setAddress(p.address || '');
          setMapUrl(p.map_url || '');
          setWhatsappUrl(p.whatsapp_url || '');
          setInstagramUrl(p.instagram_url || '');
          setFacebookUrl(p.facebook_url || '');
          setYouTubeUrl(p.youtube_url || '');
          setCustomLinks(Array.isArray(p.custom_links) ? p.custom_links : []);
          setHasUnsavedChanges(false);
        }
      })
      .catch(() => {});

    // Fetch documents
    loadDocuments();

    return () => { active = false; };
  }, [isAuthenticated, businessId, loadDocuments]);

  // ─── 3. GENERATE CARD QR CODE ──────────────────────────────────────────────
  const canonicalCardUrl = `${window.location.origin}/b/${encodeURIComponent(businessId)}/card`;

  useEffect(() => {
    if (!canonicalCardUrl) return;
    QRCode.toDataURL(canonicalCardUrl, {
      width: 320,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    })
      .then((url) => setCardQrDataUrl(url))
      .catch((err) => console.error('Failed generating Card QR:', err));
  }, [canonicalCardUrl]);

  // ─── 4. UNSAVED CHANGES WARNING ─────────────────────────────────────────────
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges]);

  const markDirty = () => {
    setHasUnsavedChanges(true);
    setSaveSuccessMsg('');
    setSaveErrorMsg('');
  };

  // ─── 5. OWNER LOGIN HANDLER ─────────────────────────────────────────────────
  const handleLogin = async (e) => {
    e.preventDefault();
    setAuthError('');
    setIsSigningIn(true);
    try {
      const payload = {
        password: ownerPassword,
        tenant_id: businessId !== 'default_business' ? businessId : undefined,
      };
      if (ownerEmail.trim()) {
        payload.email = ownerEmail.trim();
      }
      const res = await apiFetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        throw new Error(error.detail || 'Sign-in failed. Please check your credentials.');
      }
      setOwnerPassword('');
      setIsAuthenticated(true);
    } catch (err) {
      setAuthError(err.message || 'Could not sign in.');
    } finally {
      setIsSigningIn(false);
    }
  };

  // ─── 6. SAVE PROFILE ────────────────────────────────────────────────────────
  const handleSaveProfile = async (overridePublished = null) => {
    setIsSaving(true);
    setSaveSuccessMsg('');
    setSaveErrorMsg('');

    const targetPublished = overridePublished !== null ? overridePublished : isPublished;

    const payload = {
      tagline: tagline.trim(),
      phone_number: phoneNumber.trim(),
      website_url: websiteUrl.trim(),
      address: address.trim(),
      map_url: mapUrl.trim(),
      whatsapp_url: whatsappUrl.trim(),
      instagram_url: instagramUrl.trim(),
      facebook_url: facebookUrl.trim(),
      youtube_url: youtubeUrl.trim(),
      logo_path: logoPath.trim(),
      cover_image_path: coverImagePath.trim(),
      custom_links: customLinks,
      show_review_button: Boolean(showReviewButton),
      is_published: Boolean(targetPublished),
    };

    try {
      const res = await apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.detail || 'Failed to save business profile.');
      }

      const updated = await res.json();
      setIsPublished(Boolean(updated.is_published));
      setHasUnsavedChanges(false);
      setSaveSuccessMsg(
        overridePublished !== null
          ? overridePublished
            ? '🎉 Business Card published successfully!'
            : '🔒 Business Card unpublished (now private draft).'
          : '✅ Changes saved successfully!'
      );
    } catch (err) {
      setSaveErrorMsg(err.message || 'Could not save changes.');
    } finally {
      setIsSaving(false);
    }
  };

  // ─── 7. DOCUMENT UPLOAD HANDLER ─────────────────────────────────────────────
  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    setUploadError('');
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.pdf')) {
      setUploadError('Invalid file type: Please select a valid PDF file.');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setUploadError('File exceeds 10 MiB limit. Please compress your PDF before uploading.');
      return;
    }

    setUploadFile(file);
    if (!uploadDisplayName.trim()) {
      setUploadDisplayName(file.name.replace(/\.[^/.]+$/, ''));
    }
  };

  const handleUploadDocument = async (e) => {
    e.preventDefault();
    if (!uploadFile) {
      setUploadError('Please select a PDF file first.');
      return;
    }

    setIsUploading(true);
    setUploadError('');

    const formData = new FormData();
    formData.append('file', uploadFile);
    formData.append('document_type', uploadCategory);
    formData.append('display_name', uploadDisplayName.trim() || uploadFile.name);
    formData.append('is_published', 'true');

    try {
      const res = await apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/documents`, {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.detail || 'Failed to upload document.');
      }

      setUploadFile(null);
      setUploadDisplayName('');
      if (fileInputRef.current) fileInputRef.current.value = '';
      loadDocuments();
      setSaveSuccessMsg('📄 Document uploaded successfully!');
    } catch (err) {
      setUploadError(err.message || 'Upload failed.');
    } finally {
      setIsUploading(false);
    }
  };

  // ─── 8. DOCUMENT MUTATIONS (Toggle, Rename, Delete) ─────────────────────────
  const handleToggleDocPublish = async (doc) => {
    const newStatus = !doc.is_published;
    try {
      const res = await apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/documents/${doc.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_published: newStatus }),
      });
      if (res.ok) {
        setDocuments((prev) =>
          prev.map((d) => (d.id === doc.id ? { ...d, is_published: newStatus } : d))
        );
      }
    } catch {
      // Handle error gracefully
    }
  };

  const handleDeleteDoc = async (doc) => {
    const confirmed = window.confirm(`Are you sure you want to delete "${doc.display_name}"? This cannot be undone.`);
    if (!confirmed) return;

    try {
      const res = await apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/documents/${doc.id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setDocuments((prev) => prev.filter((d) => d.id !== doc.id));
        setSaveSuccessMsg('🗑️ Document deleted.');
      }
    } catch {
      setSaveErrorMsg('Could not delete document.');
    }
  };

  const handleSaveDocRename = async () => {
    if (!editingDocId) return;
    try {
      const res = await apiFetch(`/api/businesses/${encodeURIComponent(businessId)}/documents/${editingDocId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          display_name: editDocName.trim(),
          document_type: editDocCategory,
        }),
      });
      if (res.ok) {
        const updated = await res.json();
        setDocuments((prev) =>
          prev.map((d) => (d.id === editingDocId ? { ...d, ...updated } : d))
        );
        setEditingDocId(null);
      }
    } catch {
      // Handle error gracefully
    }
  };

  // ─── 9. CUSTOM LINKS MANAGEMENT ─────────────────────────────────────────────
  const handleAddCustomLink = () => {
    if (!newLinkTitle.trim() || !newLinkUrl.trim()) return;
    const formattedUrl = newLinkUrl.trim().startsWith('http')
      ? newLinkUrl.trim()
      : `https://${newLinkUrl.trim()}`;

    setCustomLinks((prev) => [
      ...prev,
      { title: newLinkTitle.trim(), url: formattedUrl, icon: 'link' },
    ]);
    setNewLinkTitle('');
    setNewLinkUrl('');
    markDirty();
  };

  const handleRemoveCustomLink = (index) => {
    setCustomLinks((prev) => prev.filter((_, i) => i !== index));
    markDirty();
  };

  const handleCopyCardUrl = () => {
    navigator.clipboard.writeText(canonicalCardUrl);
    setCardCopiedToast(true);
    setTimeout(() => setCardCopiedToast(false), 3000);
  };

  const handleDownloadCardQr = () => {
    if (!cardQrDataUrl) return;
    const a = document.createElement('a');
    a.href = cardQrDataUrl;
    a.download = `${businessId}-card-qr.png`;
    a.click();
  };

  // ─── 10. AUTH LOADING / LOGIN SCREEN ────────────────────────────────────────
  if (isCheckingSession) {
    return (
      <div className="editor-loading-state">
        <div className="editor-spinner" />
        <span>Checking access credentials...</span>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="owner-login-panel">
        <div className="owner-login-card">
          <div className="login-badge-icon">🪪</div>
          <h1 className="login-card-title">Digital Card Editor</h1>
          <p className="login-card-sub">
            Sign in to manage your digital business card, menus, and contact links for{' '}
            <strong>{businessId}</strong>.
          </p>

          {authError && (
            <div className="login-error-msg" role="alert">
              ⚠️ {authError}
            </div>
          )}

          <form onSubmit={handleLogin} className="login-form">
            <div className="login-field">
              <label htmlFor="card-editor-email">Owner Email</label>
              <input
                id="card-editor-email"
                type="email"
                value={ownerEmail}
                onChange={(e) => setOwnerEmail(e.target.value)}
                placeholder="owner@yourbusiness.com"
                autoComplete="email"
                required
              />
            </div>

            <div className="login-field">
              <label htmlFor="card-editor-pass">Password</label>
              <input
                id="card-editor-pass"
                type="password"
                value={ownerPassword}
                onChange={(e) => setOwnerPassword(e.target.value)}
                placeholder="••••••••••••"
                autoComplete="current-password"
                required
              />
            </div>

            <button type="submit" className="login-submit-btn" disabled={isSigningIn}>
              {isSigningIn ? 'Signing in...' : 'Sign In to Card Editor →'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ─── 11. ENTITLEMENT LOCK SCREEN ────────────────────────────────────────────
  if (!hasCardEntitlement) {
    return (
      <div className="editor-lock-panel">
        <div className="editor-lock-card">
          <div className="lock-icon">🔒</div>
          <h2 className="lock-title">Digital Business Card Not Enabled</h2>
          <p className="lock-desc">
            The Digital Business Card module is currently not included in the active subscription
            for <strong>{tenantName}</strong>.
          </p>
          <div className="lock-entitlements-list">
            <span>Active modules: {entitlements.join(', ')}</span>
          </div>
          {onBackToReviews && (
            <button type="button" className="lock-return-btn" onClick={onBackToReviews}>
              ← Return to Review Assistant
            </button>
          )}
        </div>
      </div>
    );
  }

  // Current draft preview data object
  const livePreviewData = {
    tenant_id: businessId,
    business_name: tenantName,
    tagline,
    logo_path: logoPath,
    cover_image_path: coverImagePath,
    phone_number: phoneNumber,
    website_url: websiteUrl,
    address,
    map_url: mapUrl,
    whatsapp_url: whatsappUrl,
    instagram_url: instagramUrl,
    facebook_url: facebookUrl,
    youtube_url: youtubeUrl,
    custom_links: customLinks,
    show_review_button: Boolean(showReviewButton),
    documents: documents.map((d) => ({
      id: d.id,
      document_type: d.document_type,
      display_name: d.display_name,
      file_size_bytes: d.file_size_bytes,
      download_url: d.download_url,
      is_published: d.is_published,
    })),
  };

  return (
    <div className="card-editor-layout">
      {/* Top Header & Publication Bar */}
      <header className="editor-top-bar">
        <div className="editor-title-block">
          <span className="editor-badge">Digital Card Studio</span>
          <h1 className="editor-heading">{tenantName}</h1>
        </div>

        <div className="editor-status-actions">
          <div className={`status-pill ${isPublished ? 'published' : 'draft'}`}>
            <span className="status-dot" />
            <span>{isPublished ? 'Published Live' : 'Draft Mode (Hidden)'}</span>
          </div>

          {hasUnsavedChanges && (
            <span className="unsaved-badge" title="You have unsaved changes">
              ● Unsaved
            </span>
          )}

          <button
            type="button"
            className="editor-btn preview"
            onClick={() => {
              if (onPreviewCard) onPreviewCard();
              else setShowLivePreview(true);
            }}
            title="Preview how visitors see your card"
          >
            👁️ Preview
          </button>

          <button
            type="button"
            className="editor-btn save"
            onClick={() => handleSaveProfile()}
            disabled={isSaving}
          >
            {isSaving ? 'Saving...' : '💾 Save Changes'}
          </button>
        </div>
      </header>

      {/* Notifications */}
      {saveSuccessMsg && (
        <div className="editor-alert success" role="alert">
          {saveSuccessMsg}
        </div>
      )}
      {saveErrorMsg && (
        <div className="editor-alert error" role="alert">
          ⚠️ {saveErrorMsg}
        </div>
      )}

      {/* Editor Navigation Tabs */}
      <nav className="editor-nav-tabs" role="tablist">
        <button
          type="button"
          role="tab"
          aria-selected={activeSection === 'details'}
          className={`editor-tab-btn ${activeSection === 'details' ? 'active' : ''}`}
          onClick={() => setActiveSection('details')}
        >
          <span>🏷️</span>
          <span>1. Business Details</span>
        </button>

        <button
          type="button"
          role="tab"
          aria-selected={activeSection === 'contact'}
          className={`editor-tab-btn ${activeSection === 'contact' ? 'active' : ''}`}
          onClick={() => setActiveSection('contact')}
        >
          <span>📍</span>
          <span>2. Contact & Maps</span>
        </button>

        <button
          type="button"
          role="tab"
          aria-selected={activeSection === 'social'}
          className={`editor-tab-btn ${activeSection === 'social' ? 'active' : ''}`}
          onClick={() => setActiveSection('social')}
        >
          <span>🌐</span>
          <span>3. Social & Links</span>
        </button>

        <button
          type="button"
          role="tab"
          aria-selected={activeSection === 'documents'}
          className={`editor-tab-btn ${activeSection === 'documents' ? 'active' : ''}`}
          onClick={() => setActiveSection('documents')}
        >
          <span>📑</span>
          <span>4. PDF Menus ({documents.length})</span>
        </button>

        <button
          type="button"
          role="tab"
          aria-selected={activeSection === 'publish'}
          className={`editor-tab-btn ${activeSection === 'publish' ? 'active' : ''}`}
          onClick={() => setActiveSection('publish')}
        >
          <span>🚀</span>
          <span>5. QR & Publish</span>
        </button>
      </nav>

      {/* Main Tab Content */}
      <main className="editor-main-panel">
        {/* SECTION 1: BUSINESS DETAILS */}
        {activeSection === 'details' && (
          <section className="editor-section" aria-label="Business details">
            <div className="section-header">
              <h2>Brand Presentation</h2>
              <p>Configure how your business is identified on the public card.</p>
            </div>

            <div className="form-group">
              <label htmlFor="card-tagline">
                Catchy Tagline / Slogan
                <span className="char-count">{tagline.length}/250</span>
              </label>
              <input
                id="card-tagline"
                type="text"
                maxLength={250}
                value={tagline}
                onChange={(e) => { setTagline(e.target.value); markDirty(); }}
                placeholder="e.g. Authentic homestyle breakfast, specialty chai & snacks"
              />
              <span className="field-hint">Displayed prominently under your business name.</span>
            </div>

            <div className="form-grid-2">
              <div className="form-group">
                <label htmlFor="card-logo">Logo Image URL</label>
                <input
                  id="card-logo"
                  type="text"
                  value={logoPath}
                  onChange={(e) => { setLogoPath(e.target.value); markDirty(); }}
                  placeholder="https://example.com/logo.png"
                />
                <span className="field-hint">Square image recommended (200x200px).</span>
              </div>

              <div className="form-group">
                <label htmlFor="card-cover">Cover Image URL (Optional)</label>
                <input
                  id="card-cover"
                  type="text"
                  value={coverImagePath}
                  onChange={(e) => { setCoverImagePath(e.target.value); markDirty(); }}
                  placeholder="https://example.com/cover.jpg"
                />
                <span className="field-hint">Banner header image for top of card.</span>
              </div>
            </div>

            <div className="form-toggle-box">
              <div className="toggle-info">
                <strong>Show 'Review Us on Google' Button</strong>
                <span>Allows card visitors to jump straight to your Google review journey.</span>
              </div>
              <label className="switch-label">
                <input
                  type="checkbox"
                  checked={showReviewButton}
                  onChange={(e) => { setShowReviewButton(e.target.checked); markDirty(); }}
                />
                <span className="switch-slider" />
              </label>
            </div>
          </section>
        )}

        {/* SECTION 2: CONTACT & MAPS */}
        {activeSection === 'contact' && (
          <section className="editor-section" aria-label="Contact and maps">
            <div className="section-header">
              <h2>Contact & Location</h2>
              <p>Help customers call, locate, and visit your business directly.</p>
            </div>

            <div className="form-grid-2">
              <div className="form-group">
                <label htmlFor="card-phone">Phone Number</label>
                <input
                  id="card-phone"
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => { setPhoneNumber(e.target.value); markDirty(); }}
                  placeholder="+91 98765 43210"
                />
                <span className="field-hint">Enables one-tap dialing from smartphones.</span>
              </div>

              <div className="form-group">
                <label htmlFor="card-website">Website URL</label>
                <input
                  id="card-website"
                  type="text"
                  value={websiteUrl}
                  onChange={(e) => { setWebsiteUrl(e.target.value); markDirty(); }}
                  placeholder="example.com"
                />
                <span className="field-hint">Auto-prefixes https:// if omitted.</span>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="card-address">Physical Address</label>
              <textarea
                id="card-address"
                rows={3}
                value={address}
                onChange={(e) => { setAddress(e.target.value); markDirty(); }}
                placeholder="Shop No. 4, Heritage Arcade, SG Highway, Ahmedabad, Gujarat 380054"
              />
            </div>

            <div className="form-group">
              <label htmlFor="card-map">Google Maps Destination URL</label>
              <input
                id="card-map"
                type="text"
                value={mapUrl}
                onChange={(e) => { setMapUrl(e.target.value); markDirty(); }}
                placeholder="https://maps.google.com/?q=..."
              />
              <span className="field-hint">Enables the 'Get Directions' button on your card.</span>
            </div>
          </section>
        )}

        {/* SECTION 3: SOCIAL & ONLINE LINKS */}
        {activeSection === 'social' && (
          <section className="editor-section" aria-label="Social and online links">
            <div className="section-header">
              <h2>Social Media & Direct Chat</h2>
              <p>Connect guests to your WhatsApp chat and social media accounts.</p>
            </div>

            <div className="form-grid-2">
              <div className="form-group">
                <label htmlFor="card-wa">WhatsApp Phone or Chat Link</label>
                <input
                  id="card-wa"
                  type="text"
                  value={whatsappUrl}
                  onChange={(e) => { setWhatsappUrl(e.target.value); markDirty(); }}
                  placeholder="+91 98765 43210 or https://wa.me/..."
                />
                <span className="field-hint">Visitors tap to start a WhatsApp conversation.</span>
              </div>

              <div className="form-group">
                <label htmlFor="card-insta">Instagram Profile URL</label>
                <input
                  id="card-insta"
                  type="text"
                  value={instagramUrl}
                  onChange={(e) => { setInstagramUrl(e.target.value); markDirty(); }}
                  placeholder="https://instagram.com/yourbusiness"
                />
              </div>

              <div className="form-group">
                <label htmlFor="card-fb">Facebook Page URL</label>
                <input
                  id="card-fb"
                  type="text"
                  value={facebookUrl}
                  onChange={(e) => { setFacebookUrl(e.target.value); markDirty(); }}
                  placeholder="https://facebook.com/yourbusiness"
                />
              </div>

              <div className="form-group">
                <label htmlFor="card-yt">YouTube Channel URL</label>
                <input
                  id="card-yt"
                  type="text"
                  value={youtubeUrl}
                  onChange={(e) => { setYouTubeUrl(e.target.value); markDirty(); }}
                  placeholder="https://youtube.com/@yourbusiness"
                />
              </div>
            </div>

            {/* Custom Links (Zomato, Swiggy, Bookings) */}
            <div className="custom-links-builder">
              <div className="sub-header">
                <h3>Custom Online Links</h3>
                <p>Add links for food delivery, table reservations, or portals.</p>
              </div>

              <div className="link-items-list">
                {customLinks.map((link, idx) => (
                  <div key={idx} className="link-item-row">
                    <span className="link-bullet">🔗</span>
                    <div className="link-item-info">
                      <span className="link-title">{link.title}</span>
                      <span className="link-url">{link.url}</span>
                    </div>
                    <button
                      type="button"
                      className="link-remove-btn"
                      onClick={() => handleRemoveCustomLink(idx)}
                      title="Remove link"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>

              <div className="add-link-box">
                <input
                  type="text"
                  value={newLinkTitle}
                  onChange={(e) => setNewLinkTitle(e.target.value)}
                  placeholder="Link Title (e.g. Order on Swiggy)"
                  className="add-link-title"
                />
                <input
                  type="text"
                  value={newLinkUrl}
                  onChange={(e) => setNewLinkUrl(e.target.value)}
                  placeholder="URL (e.g. swiggy.com/restaurants/...)"
                  className="add-link-url"
                />
                <button
                  type="button"
                  className="add-link-btn"
                  onClick={handleAddCustomLink}
                  disabled={!newLinkTitle.trim() || !newLinkUrl.trim()}
                >
                  + Add Link
                </button>
              </div>
            </div>
          </section>
        )}

        {/* SECTION 4: PDF DOCUMENTS */}
        {activeSection === 'documents' && (
          <section className="editor-section" aria-label="PDF documents management">
            <div className="section-header">
              <h2>Menus & PDF Documents</h2>
              <p>Upload digital food menus, drinks lists, or brochures (max 10 MiB per PDF).</p>
            </div>

            {/* Upload Area */}
            <form onSubmit={handleUploadDocument} className="doc-upload-box">
              <div className="file-drop-area">
                <input
                  ref={fileInputRef}
                  type="file"
                  id="pdf-file-picker"
                  accept="application/pdf,.pdf"
                  onChange={handleFileSelect}
                  className="file-input-hidden"
                />
                <label htmlFor="pdf-file-picker" className="file-drop-label">
                  <div className="upload-icon">📄</div>
                  <div className="upload-label-text">
                    {uploadFile ? (
                      <strong>Selected: {uploadFile.name} ({formatBytes(uploadFile.size)})</strong>
                    ) : (
                      <span>Click to browse or drop your PDF menu here</span>
                    )}
                  </div>
                  <span className="upload-hint">Only .pdf files up to 10 MiB supported</span>
                </label>
              </div>

              {uploadError && (
                <div className="doc-error-msg" role="alert">
                  ⚠️ {uploadError}
                </div>
              )}

              {uploadFile && (
                <div className="upload-fields-row">
                  <div className="field-col">
                    <label htmlFor="doc-display-name">Display Name</label>
                    <input
                      id="doc-display-name"
                      type="text"
                      value={uploadDisplayName}
                      onChange={(e) => setUploadDisplayName(e.target.value)}
                      placeholder="e.g. Summer Dinner Menu"
                      required
                    />
                  </div>

                  <div className="field-col">
                    <label htmlFor="doc-category">Document Category</label>
                    <select
                      id="doc-category"
                      value={uploadCategory}
                      onChange={(e) => setUploadCategory(e.target.value)}
                    >
                      {DOCUMENT_CATEGORIES.map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.icon} {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="doc-upload-submit-btn"
                    disabled={isUploading}
                  >
                    {isUploading ? 'Uploading...' : '⬆️ Upload Document'}
                  </button>
                </div>
              )}
            </form>

            {/* Document List */}
            <div className="doc-management-list">
              <h3 className="sub-title">Your Stored Documents ({documents.length})</h3>

              {isLoadingDocs ? (
                <div className="docs-loading">Loading documents...</div>
              ) : documents.length === 0 ? (
                <div className="docs-empty-state">
                  <span className="empty-icon">📂</span>
                  <p>No documents uploaded yet. Add your first PDF menu above!</p>
                </div>
              ) : (
                <div className="docs-table-wrapper">
                  <table className="docs-table">
                    <thead>
                      <tr>
                        <th>Category</th>
                        <th>Document Name</th>
                        <th>File Size</th>
                        <th>Visibility</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {documents.map((doc) => (
                        <tr key={doc.id}>
                          <td>
                            <span className="category-pill">
                              {DOCUMENT_CATEGORIES.find((c) => c.id === doc.document_type)?.icon || '📄'}{' '}
                              {DOCUMENT_CATEGORIES.find((c) => c.id === doc.document_type)?.label || 'Document'}
                            </span>
                          </td>
                          <td>
                            <div className="doc-title-cell">
                              <strong>{doc.display_name}</strong>
                              <span className="doc-raw-file">{doc.original_filename}</span>
                            </div>
                          </td>
                          <td>{formatBytes(doc.file_size_bytes)}</td>
                          <td>
                            <button
                              type="button"
                              className={`doc-visibility-btn ${doc.is_published ? 'pub' : 'draft'}`}
                              onClick={() => handleToggleDocPublish(doc)}
                              title="Click to toggle published / draft state"
                            >
                              <span className="dot" />
                              <span>{doc.is_published ? 'Published' : 'Hidden Draft'}</span>
                            </button>
                          </td>
                          <td>
                            <div className="doc-action-group">
                              <a
                                href={doc.download_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="doc-icon-btn view"
                                title="View PDF"
                              >
                                👁️
                              </a>
                              <button
                                type="button"
                                className="doc-icon-btn edit"
                                onClick={() => {
                                  setEditingDocId(doc.id);
                                  setEditDocName(doc.display_name);
                                  setEditDocCategory(doc.document_type);
                                }}
                                title="Rename document"
                              >
                                ✏️
                              </button>
                              <button
                                type="button"
                                className="doc-icon-btn delete"
                                onClick={() => handleDeleteDoc(doc)}
                                title="Delete document"
                              >
                                🗑️
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Document Rename Modal */}
            {editingDocId && (
              <div className="editor-modal-backdrop">
                <div className="editor-modal-card">
                  <h3>Edit Document Metadata</h3>
                  <div className="form-group">
                    <label>Display Name</label>
                    <input
                      type="text"
                      value={editDocName}
                      onChange={(e) => setEditDocName(e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                    <label>Category</label>
                    <select
                      value={editDocCategory}
                      onChange={(e) => setEditDocCategory(e.target.value)}
                    >
                      {DOCUMENT_CATEGORIES.map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.icon} {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="modal-buttons">
                    <button
                      type="button"
                      className="modal-cancel-btn"
                      onClick={() => setEditingDocId(null)}
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      className="modal-save-btn"
                      onClick={handleSaveDocRename}
                    >
                      Save Changes
                    </button>
                  </div>
                </div>
              </div>
            )}
          </section>
        )}

        {/* SECTION 5: QR & PUBLICATION */}
        {activeSection === 'publish' && (
          <section className="editor-section" aria-label="QR code and publishing">
            <div className="section-header">
              <h2>Publishing & Card QR Code</h2>
              <p>Control web visibility and download the QR code for your physical business card.</p>
            </div>

            {/* Master Publication Switch */}
            <div className="master-publish-banner">
              <div className="publish-desc">
                <h3>Card Web Visibility</h3>
                <p>
                  {isPublished
                    ? 'Your card is currently live and viewable by customers across the web.'
                    : 'Your card is currently hidden in draft mode. Anonymous visitors will receive a 404.'}
                </p>
              </div>
              <div className="publish-control">
                <button
                  type="button"
                  className={`master-publish-btn ${isPublished ? 'unpublish' : 'publish'}`}
                  onClick={() => handleSaveProfile(!isPublished)}
                  disabled={isSaving}
                >
                  {isPublished ? '🔒 Unpublish Card (Set Draft)' : '🚀 Publish Live to Web'}
                </button>
              </div>
            </div>

            {/* Link & QR Code Studio */}
            <div className="card-qr-studio-grid">
              <div className="qr-info-card">
                <h3>Canonical Public Card URL</h3>
                <div className="url-copy-box">
                  <input
                    type="text"
                    readOnly
                    value={canonicalCardUrl}
                    className="url-display-input"
                  />
                  <button
                    type="button"
                    className="url-copy-btn"
                    onClick={handleCopyCardUrl}
                  >
                    {cardCopiedToast ? '✅ Copied!' : '📋 Copy Link'}
                  </button>
                </div>
                <span className="field-hint">
                  Share this link directly on social media, in WhatsApp bios, or email signatures.
                </span>

                <div className="qr-actions-row">
                  <button
                    type="button"
                    className="download-qr-btn"
                    onClick={handleDownloadCardQr}
                    disabled={!cardQrDataUrl}
                  >
                    💾 Download Card QR (PNG)
                  </button>
                  <a
                    href={canonicalCardUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="test-link-btn"
                  >
                    🌐 Open Live Card ↗
                  </a>
                </div>
              </div>

              {/* QR Stand Display */}
              <div className="qr-preview-stand">
                <div className="stand-header">
                  <span className="stand-dot" />
                  <span>Card Destination QR</span>
                </div>
                <div className="stand-image-wrap">
                  {cardQrDataUrl ? (
                    <img
                      src={cardQrDataUrl}
                      alt={`QR code linking to ${canonicalCardUrl}`}
                      className="card-qr-img"
                    />
                  ) : (
                    <div className="qr-placeholder">Generating QR...</div>
                  )}
                </div>
                <div className="stand-caption">
                  <span>Scans point directly to:</span>
                  <strong>/b/{businessId}/card</strong>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Live Preview Modal */}
      {showLivePreview && (
        <div className="preview-modal-backdrop" role="dialog" aria-modal="true">
          <div className="preview-modal-window">
            <div className="preview-modal-bar">
              <span className="modal-title">📱 Live Card Preview</span>
              <button
                type="button"
                className="modal-close-btn"
                onClick={() => setShowLivePreview(false)}
                aria-label="Close preview"
              >
                ✕ Close
              </button>
            </div>
            <div className="preview-modal-viewport">
              <DigitalCard
                businessId={businessId}
                isPreview={true}
                previewData={livePreviewData}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
