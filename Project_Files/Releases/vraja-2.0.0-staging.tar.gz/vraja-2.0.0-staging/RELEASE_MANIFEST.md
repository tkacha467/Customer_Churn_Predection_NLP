# Vraja Release Artifact Manifest — Version 2.0.0-staging

- **Build Timestamp**: `2026-10-21T18:51:27Z`
- **Total Files**: `125`
- **Health Endpoint**: `GET /healthz` (HTTP 200 `{"status": "ok"}`)

## Deployment Quickstart

1. **Install Dependencies**:
   ```bash
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   ```

2. **Configure Environment**:
   ```bash
   cp staging.env.example .env
   # Edit .env with staging FQDN and random OWNER_SESSION_SECRET
   ```

3. **Bootstrap Initial Superadmin**:
   ```bash
   python scripts/create_tenant_owner.py \
     --email admin@staging.vraja.local \
     --tenant default_business \
     --role owner \
     --name "Platform Admin" \
     --platform-admin \
     --password-stdin
   ```

4. **Launch Server**:
   ```bash
   uvicorn api.main:app --host 127.0.0.1 --port 8000
   ```

## File Verification Manifest

| Relative Path | Size (Bytes) | SHA-256 Checksum |
|---|---:|---|
| `pyproject.toml` | 457 | `60a25cfe1c5176aabddacf55468db80eec6c398a52d3a5224bd81f61ee987e43` |
| `requirements.txt` | 205 | `164f868af305151913263ab4bb5bc44899b0f9375a71d7624c17a3da5e907a30` |
| `staging.env.example` | 1,350 | `ef099ad8679b70061836e482334d94d8e60544cd74f266880ec42451fea8e41d` |
| `frontend/package-lock.json` | 55,483 | `5f1ee3726c2ea3af609af658813cc1002a99727ea3a6f4b50b35abe0bfc4b30e` |
| `frontend/package.json` | 483 | `7f4f96513677b3ca4917e7c2a21fd2325fd60bfadc273b700ba25278e5b1d95a` |
| `frontend/dist/favicon.svg` | 9,522 | `61bc9a161de58248288e6905425d7180f0624c2865007b97d763fdac12043a66` |
| `frontend/dist/icons.svg` | 5,031 | `b45fa506195cfcdef406ba9f0c77b36ddc1a7c224040926ec70abc2fdea7b93a` |
| `frontend/dist/index.html` | 1,156 | `f1f5aebabdec038aba9ff680cba93f810f17517f2f4539bb5ed3f9b1bda2cd47` |
| `frontend/dist/restaurant/darshan-host.png` | 315,199 | `a69ded9cb9bd88003403460e50f23abfd2435e2c077d2194f6d4fe21f08ccac6` |
| `frontend/dist/restaurant/scene-phone.webp` | 251,728 | `830c53e440ba3571bc4b0b6d091c78861f5744864f6c3a9c6d0be4dbaadd3494` |
| `frontend/dist/restaurant/scene-wide.webp` | 349,362 | `02b8cd404109ec62dd2fef52784aff8413255cf4b93c9710d5adcb3d311f7221` |
| `frontend/dist/assets/index-Cfx-A_Sx.css` | 104,708 | `977e51d2577dfd016929ffb29e64405f6a4ecf94521b5e551bddc29958c3cbb5` |
| `frontend/dist/assets/index-D0gx_hiH.js` | 373,338 | `ea8735e501eb31923a6c4e99ede1889b60bb6282ef61a3d0602439fb4d2182e0` |
| `product-c-mastercard/README.md` | 1,152 | `769afb8e17809339cecf802c93b50b7689994f1691ac834190a96d6810100566` |
| `product-c-mastercard/frontend/.gitkeep` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `product-c-mastercard/assets/.gitkeep` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/.gitkeep` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/README.md` | 1,353 | `dd9f1d820361d6beb0f308b550143fb47ac800ba1f7ef70a0efba9f18b37995d` |
| `Backend/__init__.py` | 25 | `1e81810dbfc61df3dbd4a756190a5ed6c3121cbf3a9df95c95367baa0fcecb6c` |
| `Backend/app/__init__.py` | 313 | `69c6b3cc436eb2a204e957396d8014794eeeeb8515418436a8e3e06cee2f8b80` |
| `Backend/app/main.py` | 8,373 | `144ad86177bb6e8f2fb24469f280137cde86ddeef058e4ecd56321755ce13295` |
| `Backend/app/schemas.py` | 15,789 | `e58fc8c65d14311816c7655800e97c0f229dd5e566daae654bd35453eedfdf08` |
| `Backend/app/fusion/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/fusion/engine.py` | 2,311 | `e27bdb3814c7c7c2108b4c2a2e859a965087b8c1e73fe5466ee762c0c6bb94a5` |
| `Backend/app/fusion/explainer.py` | 1,176 | `84e50a3207d65d205959f99c62647f676eb0a4c4c98a0f066a5e3c222db9ab5f` |
| `Backend/app/core/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/core/database/migration.py` | 3,776 | `fcfd7d5e8cf1cf1a5589747fa794c75de7d2a1b725bd6629db83e1cd737aa425` |
| `Backend/app/core/database/storage.py` | 41,574 | `5f3f8eee43fba14f3699ce6d17cda8a28769497c4dc361f42545e9b5ab7829e0` |
| `Backend/app/core/auth/auth.py` | 13,192 | `fb6a1aa02efdb2ba69997653d66eb5a43692242adeaf149ed9a518ae789dc678` |
| `Backend/app/core/tenants/business_links.json` | 2,420 | `40777e4accb28c9c7bf6e485dbf060644d6a456b3a8e5538c2d044b79ae87fc3` |
| `Backend/app/core/tenants/google_reviews.py` | 13,274 | `be2133e510482eb77b91ca0c3427a9a315be10d4f19c97fe92b3af15e97f2f6e` |
| `Backend/app/core/entitlements/entitlements.py` | 2,152 | `0c0addd65e828e0bfa67d475546637e8254be4d0de01ddc580dbac64bab21aa0` |
| `Backend/app/config/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/config/settings.py` | 1,011 | `af2464c0ac50989862f94f4d50d61ce7782f3152ce5021cc6fba29efdfeb98c5` |
| `Backend/app/models/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/models/model_loader.py` | 3,929 | `38dff3b68f19518bfb0de257c1488dfc7d453075343fa5560428432d094e1f46` |
| `Backend/app/models/sarcasm.py` | 841 | `6a0a5b13cccd4ce0f07e49c30280cda31596f227f0bf61c4d2f3f3548a5ca3af` |
| `Backend/app/models/sentiment.py` | 1,411 | `f0022c273982865c71e104335f7be41d49db720ceb3d62a69533717e554e7b10` |
| `Backend/app/api/__init__.py` | 117 | `e4bea166be47f7ed6a729751f64fc5bd19e44492a3372ec453289e41d88fa97c` |
| `Backend/app/api/business_links.json` | 2,420 | `40777e4accb28c9c7bf6e485dbf060644d6a456b3a8e5538c2d044b79ae87fc3` |
| `Backend/app/api/document_storage.py` | 9,383 | `f5c153f6ead4c584d6c2c4dbb603f05d51a3bcbf94fc04225d9cfc52f06008b0` |
| `Backend/app/api/generator.py` | 3,770 | `ce41a1ba312b650036e552364999aca70905ce163f2dd2351a4c007eea9fa530` |
| `Backend/app/api/llm_provider.py` | 8,584 | `830989386d52ab57ffd822f0c6f5252abdcede02a2ef353a3dc484716f736da8` |
| `Backend/app/api/prompts.py` | 29,059 | `00b11c2b6a49c9222ecef3e0d3a1450d3a6c1563b79e2fdb835fba9e810bef25` |
| `Backend/app/api/routes.py` | 45,487 | `f47f00814938f18e7b10d91ced45b613aa18dac0521cbeb7bcdae66f9ce35cb0` |
| `Backend/app/api/service.py` | 12,548 | `6403710be0cd886fef32cc1fc4f86649f56dfd83f684ac08e02699ef8cf87c48` |
| `Backend/app/api/validator.py` | 3,590 | `2fbba9bc03b2135a534ac05c8577a049294e0ef8160ae26538179cd3bab6d5f9` |
| `Backend/app/preprocessing/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `Backend/app/preprocessing/text_cleaner.py` | 1,895 | `18477ab046e5ce4055fde15fd80e2c1ea8fb3ffc42cbbf4a3d7f4387558fa238` |
| `product-b/README.md` | 1,034 | `e49d2b40ee0469d9e62828a937fe6fb85c0a4caaf2b3f826908eab427be5ed17` |
| `product-b/frontend/.oxlintrc.json` | 51 | `257efb2596a766451ea16a9090681e7391be76bff5a595277d51789120ce167e` |
| `product-b/frontend/index.html` | 1,058 | `fa4833aa83c70467353dd2e0de003c8ae4a833ab2a7d4bcd10524e7f82310cde` |
| `product-b/frontend/package-lock.json` | 55,483 | `5f1ee3726c2ea3af609af658813cc1002a99727ea3a6f4b50b35abe0bfc4b30e` |
| `product-b/frontend/package.json` | 483 | `7f4f96513677b3ca4917e7c2a21fd2325fd60bfadc273b700ba25278e5b1d95a` |
| `product-b/frontend/vite.config.js` | 429 | `3a2c69010f98c0ea21354b34e22a2aecd9e902381c5692d10a1b77f1cf389ab3` |
| `product-b/frontend/public/favicon.svg` | 9,522 | `61bc9a161de58248288e6905425d7180f0624c2865007b97d763fdac12043a66` |
| `product-b/frontend/public/icons.svg` | 5,031 | `b45fa506195cfcdef406ba9f0c77b36ddc1a7c224040926ec70abc2fdea7b93a` |
| `product-b/frontend/public/restaurant/darshan-host.png` | 315,199 | `a69ded9cb9bd88003403460e50f23abfd2435e2c077d2194f6d4fe21f08ccac6` |
| `product-b/frontend/public/restaurant/scene-phone.webp` | 251,728 | `830c53e440ba3571bc4b0b6d091c78861f5744864f6c3a9c6d0be4dbaadd3494` |
| `product-b/frontend/public/restaurant/scene-wide.webp` | 349,362 | `02b8cd404109ec62dd2fef52784aff8413255cf4b93c9710d5adcb3d311f7221` |
| `product-b/frontend/src/App.jsx` | 2,339 | `980054586a8a8fff7652f6c966ea9872452a2d0b86eae96f7a4304197dc96c78` |
| `product-b/frontend/src/index.css` | 132,152 | `9f424747b048a4977c16dfda64b0a17350987d6b437815a77db23c3b3b6a27b2` |
| `product-b/frontend/src/main.jsx` | 229 | `4b4b864dbe45253425d0c925337180ec07e204295179f80f59551216f466f618` |
| `product-b/frontend/src/components/DigitalCard.jsx` | 20,808 | `9de2d8d2048b15fcb3291eaae492115a044c05acc0763c3cb4480e9def7026c3` |
| `product-b/frontend/src/components/DigitalCardEditor.jsx` | 47,139 | `f9f988c66c25a41c853804672a800a4df7d9fe72289cd669e95e53e1f8659e83` |
| `product-b/frontend/src/lib/api.js` | 369 | `54c3e3da70d7fd64be2fcfa3d5cf5af9e0a2f05cda35220baaa17af9e117c51c` |
| `scripts/backup_restore.py` | 12,430 | `211cfce26971b48b1294c17d68e7fe7286c12f731fac33f2e59d75cbdf9e3e3d` |
| `scripts/create_tenant_owner.py` | 6,148 | `95cd32184640436da458b9dea2749217f79d14a724a95f7871c2b3000d1746c2` |
| `api/README.md` | 28 | `83afc67ff607aed75fd13ec80714f93f13d513bb5b6cb4535a96687a088b430f` |
| `api/__init__.py` | 425 | `74c1e6d8bc4320d73866bae44876564c92e3e60699283fa3944ae0132dc38a2d` |
| `api/main.py` | 563 | `ee1c1255ba15fa544d7e56f1ec7b10f2a1a31be229c183212e3249a3f997298e` |
| `api/fusion/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `api/fusion/engine.py` | 152 | `80acd3875e39cdff7978b56d5940329f4d9e8bd236c0dda254ddd89a761df868` |
| `api/fusion/explainer.py` | 154 | `d1555a22289e3e6cb4412fffedc951fec20803d430f12d24bb317be4d921201a` |
| `api/config/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `api/config/settings.py` | 163 | `a9d1f2fe960c0adb7bc4c9a07108be7ced128407a9bc9dfea4e2faaaa2c8a139` |
| `api/review_assistant/__init__.py` | 235 | `6b664e77d7519a53b1ed9a12a542969ddf44c6f768f3823d6e4b9b9fe09405e1` |
| `api/review_assistant/auth.py` | 277 | `c12118cbf17b118e777ef6f3ad2270a0defcd5231200a6b648c1c920e5a752da` |
| `api/review_assistant/business_links.json` | 2,420 | `40777e4accb28c9c7bf6e485dbf060644d6a456b3a8e5538c2d044b79ae87fc3` |
| `api/review_assistant/document_storage.py` | 256 | `9a1437d98cd0f9a3305204587d6af63ea8509b3b77bf5b4c82899f37a8ce56c9` |
| `api/review_assistant/entitlements.py` | 200 | `623ef43eb94e8ed2fe559d67eb8d8b8f2b138363cd5a4fc011ddb12e0f7515f5` |
| `api/review_assistant/generator.py` | 155 | `c3c60dc8bbfc251ace5c065d38a53b558f26650478a858c197e6b1f11392f3cd` |
| `api/review_assistant/google_reviews.py` | 214 | `5aa7d5cb391a74af33b8d3427fb06a9d152835400681c0072c2d5f1f531079db` |
| `api/review_assistant/llm_provider.py` | 164 | `2b503cfc8cbbfbc6dc885b4c74fa2ddd0976002eb70592c096470092da23c15e` |
| `api/review_assistant/migration.py` | 234 | `80dec2d40e99eaf7e44a0c5e40aa0dcc41b3881c543b1d71454f3d70b8c4a03f` |
| `api/review_assistant/prompts.py` | 149 | `306351afa0ffc6daf43ca92c378b63360d84d4ecf8bb5f1922d4b569917ad1e9` |
| `api/review_assistant/routes.py` | 177 | `3328d4f7e8d72504e584d2218bf13516dcb05cb36d96e891ab0fd7635d655497` |
| `api/review_assistant/schemas.py` | 157 | `cc672f0d16fe3c6317ff5c1b8e47ea50b9a14fcc7459b0b3b45ab5b090b65c5a` |
| `api/review_assistant/service.py` | 148 | `6df1dc8eca4fe49c786ad9152b24dc0693a9c8f35ceb25b8c6d8e1e9863cb5fb` |
| `api/review_assistant/storage.py` | 233 | `b189b57de92c9fa3438a47bf4f48f0e7d62c8dda1e85cdd2e252272c66de2aca` |
| `api/review_assistant/validator.py` | 155 | `6a13dc4415b86f3e1c1f74c6844a61e45e14ab6303bdb93485c6e18c4c4977f4` |
| `api/models/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `api/models/model_loader.py` | 163 | `c1df90bbdff3234326ec884d0bb1d7e602b3b8bf8e26bff349ff401c5f3dcaa6` |
| `api/models/sarcasm.py` | 154 | `ad1fd5614993c029269ff192cc7d8c7740fb85cd6cd106f1fbc5191b6be84f99` |
| `api/models/sentiment.py` | 160 | `9755015ddc1dc571d99df2ad230bfbcce8ffe5c70d8722394b52ef6bcdd241e8` |
| `api/preprocessing/__init__.py` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `api/preprocessing/text_cleaner.py` | 177 | `6f63f098889210cd1c660f27540d6395779b8a44053c89037a5ded7945fde0a1` |
| `nastaghar/README.md` | 1,053 | `1ff889946f7aa94136ffcdc7799461a0fd4fd84ec0e3182c33175bbae3f41c2f` |
| `nastaghar/frontend/.oxlintrc.json` | 51 | `257efb2596a766451ea16a9090681e7391be76bff5a595277d51789120ce167e` |
| `nastaghar/frontend/index.html` | 1,058 | `fa4833aa83c70467353dd2e0de003c8ae4a833ab2a7d4bcd10524e7f82310cde` |
| `nastaghar/frontend/package-lock.json` | 55,483 | `5f1ee3726c2ea3af609af658813cc1002a99727ea3a6f4b50b35abe0bfc4b30e` |
| `nastaghar/frontend/package.json` | 483 | `7f4f96513677b3ca4917e7c2a21fd2325fd60bfadc273b700ba25278e5b1d95a` |
| `nastaghar/frontend/vite.config.js` | 845 | `d2c235e8f15e5af42a1e8e58b0d7b395be2b9d88e02e9ac2996c045f328a010e` |
| `nastaghar/frontend/public/favicon.svg` | 9,522 | `61bc9a161de58248288e6905425d7180f0624c2865007b97d763fdac12043a66` |
| `nastaghar/frontend/public/icons.svg` | 5,031 | `b45fa506195cfcdef406ba9f0c77b36ddc1a7c224040926ec70abc2fdea7b93a` |
| `nastaghar/frontend/public/restaurant/darshan-host.png` | 315,199 | `a69ded9cb9bd88003403460e50f23abfd2435e2c077d2194f6d4fe21f08ccac6` |
| `nastaghar/frontend/public/restaurant/scene-phone.webp` | 251,728 | `830c53e440ba3571bc4b0b6d091c78861f5744864f6c3a9c6d0be4dbaadd3494` |
| `nastaghar/frontend/public/restaurant/scene-wide.webp` | 349,362 | `02b8cd404109ec62dd2fef52784aff8413255cf4b93c9710d5adcb3d311f7221` |
| `nastaghar/frontend/src/App.jsx` | 8,940 | `efebe4365f77501ada08a097bb929667c53217b969bc6c54b2471c134f9b721d` |
| `nastaghar/frontend/src/index.css` | 132,152 | `9f424747b048a4977c16dfda64b0a17350987d6b437815a77db23c3b3b6a27b2` |
| `nastaghar/frontend/src/main.jsx` | 229 | `4b4b864dbe45253425d0c925337180ec07e204295179f80f59551216f466f618` |
| `nastaghar/frontend/src/components/CustomerReview.jsx` | 56,809 | `41db5158f8a8078b4a0463f465ac54eeaff40c930b55a6498e817c2c43470170` |
| `nastaghar/frontend/src/components/DigitalCard.jsx` | 20,808 | `9de2d8d2048b15fcb3291eaae492115a044c05acc0763c3cb4480e9def7026c3` |
| `nastaghar/frontend/src/components/DigitalCardEditor.jsx` | 47,139 | `f9f988c66c25a41c853804672a800a4df7d9fe72289cd669e95e53e1f8659e83` |
| `nastaghar/frontend/src/components/NastaGharRestaurantScene.jsx` | 30,485 | `1d27be4b1794310b062455beb7cb18ff79023040bba61e2e8182697785dbad75` |
| `nastaghar/frontend/src/components/OwnerPortal.jsx` | 39,128 | `f840d659370914f1895d0694f3d465e70667f3066c9da9f26a1057a026171f9b` |
| `nastaghar/frontend/src/components/RestaurantWorld.css` | 15,871 | `33b19b9a33101b1610ad7387345a452c476d194767d8659e8102285d47b4d2c0` |
| `nastaghar/frontend/src/components/RestaurantWorld.jsx` | 7,414 | `c0d2d58351f7d78939c4545693af8eff129f7042c4c38e3347808a767888859a` |
| `nastaghar/frontend/src/components/VrajaAdmin.jsx` | 44,524 | `5ae34cabebd272048bac0b6d807daa421005a9de3fc2e2ecb181dfd05f1d9f17` |
| `nastaghar/frontend/src/lib/api.js` | 345 | `ac2750903bd6a79939d6e30d3fe7a9f5943c8f567a07a1d6f6367804ece72832` |
| `nastaghar/assets/darshan-host.png` | 315,199 | `a69ded9cb9bd88003403460e50f23abfd2435e2c077d2194f6d4fe21f08ccac6` |
| `nastaghar/assets/scene-phone.webp` | 251,728 | `830c53e440ba3571bc4b0b6d091c78861f5744864f6c3a9c6d0be4dbaadd3494` |
| `nastaghar/assets/scene-wide.webp` | 349,362 | `02b8cd404109ec62dd2fef52784aff8413255cf4b93c9710d5adcb3d311f7221` |
