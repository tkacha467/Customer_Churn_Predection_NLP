"""
Vraja Platform API Package.
"""

from app.api.routes import router as review_router

__all__ = ["review_router"]
