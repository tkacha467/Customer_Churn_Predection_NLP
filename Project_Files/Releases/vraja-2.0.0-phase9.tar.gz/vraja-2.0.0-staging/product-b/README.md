# Product B — Digital Business Card

Independent frontend application for the Digital Business Card product.

## Structure

```text
product-b/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── DigitalCard.jsx        # Public business card view
│   │   │   └── DigitalCardEditor.jsx  # Owner card customization & PDF document manager
│   │   ├── lib/
│   │   │   └── api.js                 # API client connecting to Backend
│   │   ├── App.jsx
│   │   ├── index.css
│   │   └── main.jsx
│   ├── public/
│   ├── package.json
│   ├── package-lock.json
│   └── vite.config.js
├── assets/
└── README.md
```

## Running Product B Frontend

```bash
cd product-b/frontend
npm run dev
# Running on http://127.0.0.1:5174
```

Connects to the shared backend on port 8000 via `/api` proxy.
All authentication, authorization, and document storage are enforced by the shared backend.

## Backend URL configuration

The frontend uses same-origin `/api` requests by default. For local Vite development, set `VITE_BACKEND_URL` in `product-b/frontend/.env.local` (for example, `http://127.0.0.1:8000`) to configure the dev proxy. For a deployment with a same-origin reverse proxy, keep `VITE_API_BASE_URL` empty. A direct public API origin can be supplied through `VITE_API_BASE_URL`; it must contain no credentials or secrets.
