# NastaGhar Frontend & Review System

This directory contains the customer-facing Review Assistant experience, restaurant ambience presentation, and restaurant owner portal.

## Structure

```text
nastaghar/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── CustomerReview.jsx
│   │   │   ├── OwnerPortal.jsx
│   │   │   ├── RestaurantWorld.jsx
│   │   │   ├── RestaurantWorld.css
│   │   │   └── NastaGharRestaurantScene.jsx
│   │   ├── lib/
│   │   │   └── api.js
│   │   ├── App.jsx
│   │   ├── index.css
│   │   └── main.jsx
│   ├── public/
│   ├── package.json
│   ├── package-lock.json
│   └── vite.config.js
├── assets/
│   ├── darshan-host.png
│   ├── scene-phone.webp
│   └── scene-wide.webp
└── README.md
```

## Running NastaGhar Frontend

```bash
cd nastaghar/frontend
npm run dev
# Running on http://127.0.0.1:5173
```

## Backend URL configuration

The frontend uses same-origin `/api` requests by default. For local Vite development, set `VITE_BACKEND_URL` in `nastaghar/frontend/.env.local` (for example, `http://127.0.0.1:8000`) to configure the dev proxy. For a deployment with a same-origin reverse proxy, keep `VITE_API_BASE_URL` empty. A direct public API origin can be supplied through `VITE_API_BASE_URL`; it must contain no credentials or secrets.
